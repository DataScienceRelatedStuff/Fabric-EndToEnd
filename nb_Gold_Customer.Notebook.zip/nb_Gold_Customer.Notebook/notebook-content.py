# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "8c247cbb-3313-46b8-a547-96af85cf523f",
# META       "default_lakehouse_name": "lh_EndToEnd",
# META       "default_lakehouse_workspace_id": "fa0e52bd-b9c0-4f5a-8da4-017a12a4a832"
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC create table if not exists lh_EndToEnd.gold_Customer
# MAGIC (
# MAGIC     Customer_ID     string,
# MAGIC     Customer_Name   string,
# MAGIC     Segment         string,
# MAGIC     City            string,
# MAGIC     State           string,
# MAGIC     Country         string,
# MAGIC     Region          string,
# MAGIC     Created_TS      timestamp,
# MAGIC     Modified_TS   	timestamp
# MAGIC )
# MAGIC using delta

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

Max_Date=spark.sql("""select coalesce(max(Modified_TS),'1900-01-01') from lh_EndToEnd.gold_Customer""").first()[0]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

Max_Date

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


df_bronze=spark.read.table("lh_EndToEnd.bronze_sales")

df_final=df_bronze.selectExpr("Customer_ID","Customer_Name","Segment","City","State", \
                   "Country","Region")\
                   .where(col("Modified_TS")>Max_Date)\
                   .drop_duplicates()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_final.createOrReplaceTempView("ViewCustomer")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC select * from ViewCustomer limit 3

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC Merge into lh_EndtoEnd.gold_customer as gc
# MAGIC using ViewCustomer as vc
# MAGIC on gc.Customer_ID=vc.Customer_ID
# MAGIC when matched then 
# MAGIC update set
# MAGIC gc.Customer_Name =  	vc.Customer_Name,
# MAGIC gc.Segment =        	vc.Segment,
# MAGIC gc.City	=           	vc.City,
# MAGIC gc.State =	            vc.State,
# MAGIC gc.Country =            vc.Country,
# MAGIC gc.Region =             vc.Region,
# MAGIC gc.Modified_TS =	    current_timestamp()	
# MAGIC 
# MAGIC when not matched then insert
# MAGIC (
# MAGIC gc.Customer_ID,
# MAGIC gc.Customer_Name,
# MAGIC gc.Segment,
# MAGIC gc.City,
# MAGIC gc.State,
# MAGIC gc.Country,
# MAGIC gc.Region,
# MAGIC gc.Created_TS,
# MAGIC gc.Modified_TS	
# MAGIC )
# MAGIC values
# MAGIC (
# MAGIC vc.Customer_ID,
# MAGIC vc.Customer_Name,
# MAGIC vc.Segment,
# MAGIC vc.City,
# MAGIC vc.State,
# MAGIC vc.Country,
# MAGIC vc.Region,
# MAGIC current_timestamp(),
# MAGIC current_timestamp
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC select * from gold_customer limit 5

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }
