# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "8c247cbb-3313-46b8-a547-96af85cf523f",
# META       "default_lakehouse_name": "lh_EndToEnd",
# META       "default_lakehouse_workspace_id": "fa0e52bd-b9c0-4f5a-8da4-017a12a4a832"
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC create table if not EXISTS lh_EndToEnd.gold_date
# MAGIC (
# MAGIC BusinessDate        Date,
# MAGIC Business_Year       int,
# MAGIC Business_Quarter    int,
# MAGIC Business_Month      int,
# MAGIC Business_Week       int
# MAGIC )
# MAGIC using DELTA
# MAGIC PARTITIONED by (Business_Year)

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

start_date='2015-01-01'
end_date='2030-12-31'

date_diff=spark.sql("select date_diff('{}','{}')".format(end_date,start_date)).first()[0]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

date_diff

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

ID_Data=spark.range(0,date_diff)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

ID_Data.head(10)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

date_data=ID_Data.selectExpr("date_add('{}',cast(id as int)) as BusinessDate".format(start_date))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

date_data.show()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

date_data.createOrReplaceTempView("ViewDate")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC select
# MAGIC *
# MAGIC  from ViewDate

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC select * from lh_EndToEnd.gold_date;

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC delete from lh_EndToEnd.gold_date;


# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC select
# MAGIC *,
# MAGIC Year(BusinessDate) as Business_Year,
# MAGIC Quarter(BusinessDate) as Business_Quarter,
# MAGIC Month(BusinessDate) as Business_Month,
# MAGIC Weekday(BusinessDate) as Business_Week,
# MAGIC Day(BusinessDate) as Business_Day
# MAGIC  from ViewDate

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC insert into lh_EndToEnd.gold_date
# MAGIC select
# MAGIC *,
# MAGIC Year(BusinessDate) as Business_Year,
# MAGIC Quarter(BusinessDate) as Business_Quarter,
# MAGIC Month(BusinessDate) as Business_Month,
# MAGIC Weekday(BusinessDate) as Business_Week
# MAGIC  from ViewDate

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC select * from lh_EndToEnd.gold_date limit 15

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }
