# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "8c247cbb-3313-46b8-a547-96af85cf523f",
# META       "default_lakehouse_name": "lh_EndToEnd",
# META       "default_lakehouse_workspace_id": "fa0e52bd-b9c0-4f5a-8da4-017a12a4a832",
# META       "known_lakehouses": [
# META         {
# META           "id": "8c247cbb-3313-46b8-a547-96af85cf523f"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *
import pandas as pd


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_sales = pd.read_excel("abfss://fa0e52bd-b9c0-4f5a-8da4-017a12a4a832@onelake.dfs.fabric.microsoft.com/8c247cbb-3313-46b8-a547-96af85cf523f/Files/Current/Sales*.xlsx", sheet_name="Sales")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df1=spark.createDataFrame(df_sales)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df1.head(1)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(df1.head(15))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_returns = pd.read_excel("abfss://fa0e52bd-b9c0-4f5a-8da4-017a12a4a832@onelake.dfs.fabric.microsoft.com/8c247cbb-3313-46b8-a547-96af85cf523f/Files/Current/Sales*.xlsx", sheet_name="Returns")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df2=spark.createDataFrame(df_returns)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df2.head(1)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(df2.head(15))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_final = df1.join(df2, df1.Order_ID==df2.Order_ID, how="left").show(2)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_final = df1.join(df2, df1.Order_ID==df2.Order_ID, how="left").drop(df2.Order_ID, df2.Customer_Name, df2.Sales_Amount).show(2)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_final = df1.join(df2, df1.Order_ID==df2.Order_ID, how="left").drop(df2.Order_ID, df2.Customer_Name, df2.Sales_Amount)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(df_final.head(2))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_mod = df_final.withColumns({"Order_Year": year("Order_Date"), \
                "Order_Month": month("Order_Date"), \
                "Created_TS": current_timestamp(),\
                "Modified_TS": current_timestamp(),\
                })

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(df_mod.head(5))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_mod.createOrReplaceTempView("ViewSales")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC create table if not EXISTS lh_EndToEnd.Bronze_Sales
# MAGIC (
# MAGIC     Order_ID            string,
# MAGIC     Order_Date          Date,
# MAGIC     Shipping_Date       Date,
# MAGIC     Aging               int,
# MAGIC     Ship_Mode           string,
# MAGIC     Product_Category    string,
# MAGIC     Product             string,
# MAGIC     Sales               float,
# MAGIC     Quantity            float,
# MAGIC     Discount            float,
# MAGIC     Profit              float,
# MAGIC     Shipping_Cost       float,
# MAGIC     Order_Priority      string,
# MAGIC     Customer_ID         string,
# MAGIC     Customer_Name       string,
# MAGIC     Segment             string,
# MAGIC     City                string,
# MAGIC     State               string,
# MAGIC     Country             string,
# MAGIC     Region              string,
# MAGIC     Return              string,
# MAGIC     Order_Year          int,
# MAGIC     Order_Month         int,
# MAGIC     Created_TS          timestamp,
# MAGIC     Modified_TS         timestamp
# MAGIC )
# MAGIC using delta
# MAGIC PARTITIONED by (Order_Year, Order_Month)

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC Merge into lh_EndToEnd.Bronze_Sales as BS
# MAGIC using ViewSales as VS
# MAGIC on  BS.Order_Year=VS.Order_Year and BS.Order_Month=VS.Order_Month and BS.Order_ID=VS.Order_ID
# MAGIC when matched then 
# MAGIC update SET
# MAGIC BS.Order_Date =	        VS.Order_Date,
# MAGIC BS.Shipping_Date =  	VS.Shipping_Date,
# MAGIC BS.Aging =          	VS.Aging,
# MAGIC BS.Ship_Mode =          VS.Ship_Mode,
# MAGIC BS.Product_Category	=	VS.Product_Category,
# MAGIC BS.Product =	        VS.Product,
# MAGIC BS.Sales =	            VS.Sales,
# MAGIC BS.Quantity	=	        VS.Quantity,
# MAGIC BS.Discount	=	        VS.Discount,
# MAGIC BS.Profit = 	        VS.Profit,
# MAGIC BS.Shipping_Cost =  	VS.Shipping_Cost,
# MAGIC BS.Order_Priority = 	VS.Order_Priority,
# MAGIC BS.Customer_ID =        VS.Customer_ID,
# MAGIC BS.Customer_Name =      VS.Customer_Name,
# MAGIC BS.Segment =            VS.Segment,
# MAGIC BS.City	=	            VS.City,
# MAGIC BS.State =              VS.State,
# MAGIC BS.Country =            VS.Country,
# MAGIC BS.Region =         	VS.Region,
# MAGIC BS.Return =         	VS.Return,
# MAGIC BS.Modified_TS =        VS.Modified_TS
# MAGIC 
# MAGIC 
# MAGIC when not matched then 
# MAGIC INSERT
# MAGIC (
# MAGIC BS.Order_ID,    
# MAGIC BS.Order_Date,
# MAGIC BS.Shipping_Date,
# MAGIC BS.Aging,
# MAGIC BS.Ship_Mode,
# MAGIC BS.Product_Category,
# MAGIC BS.Product,
# MAGIC BS.Sales,
# MAGIC BS.Quantity,
# MAGIC BS.Discount,
# MAGIC BS.Profit,
# MAGIC BS.Shipping_Cost,
# MAGIC BS.Order_Priority,
# MAGIC BS.Customer_ID,
# MAGIC BS.Customer_Name,
# MAGIC BS.Segment,
# MAGIC BS.City,
# MAGIC BS.State,
# MAGIC BS.Country,
# MAGIC BS.Region,
# MAGIC BS.Return,
# MAGIC BS.Order_Year,
# MAGIC BS.Order_Month,
# MAGIC BS.Created_TS,
# MAGIC BS.Modified_TS	
# MAGIC )
# MAGIC values
# MAGIC (
# MAGIC VS.Order_ID,
# MAGIC VS.Order_Date,
# MAGIC VS.Shipping_Date,
# MAGIC VS.Aging,
# MAGIC VS.Ship_Mode,
# MAGIC VS.Product_Category,
# MAGIC VS.Product,
# MAGIC VS.Sales,
# MAGIC VS.Quantity,
# MAGIC VS.Discount,
# MAGIC VS.Profit,
# MAGIC VS.Shipping_Cost,
# MAGIC VS.Order_Priority,
# MAGIC VS.Customer_ID,
# MAGIC VS.Customer_Name,
# MAGIC VS.Segment,
# MAGIC VS.City,
# MAGIC VS.State,
# MAGIC VS.Country,
# MAGIC VS.Region,
# MAGIC VS.Return,
# MAGIC VS.Order_Year,
# MAGIC VS.Order_Month,
# MAGIC VS.Created_TS,
# MAGIC VS.Modified_TS	
# MAGIC 
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC select * from lh_EndToEnd.Bronze_Sales limit 25

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }
