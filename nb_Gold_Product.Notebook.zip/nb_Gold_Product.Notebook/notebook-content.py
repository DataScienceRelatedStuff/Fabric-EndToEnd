# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "8c247cbb-3313-46b8-a547-96af85cf523f",
# META       "default_lakehouse_name": "lh_EndToEnd",
# META       "default_lakehouse_workspace_id": "fa0e52bd-b9c0-4f5a-8da4-017a12a4a832"
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC create table if not exists lh_EndToEnd.gold_product
# MAGIC (
# MAGIC     Product_ID          Long,
# MAGIC     Product_Category	string,
# MAGIC     Product             string,
# MAGIC     Created_TS          timestamp,
# MAGIC     Modified_TS         timestamp
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

Max_Date=spark.sql("select coalesce(max(Modified_TS),'1900-01-01') from lh_EndToEnd.gold_product").first()[0]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

Max_Date

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_bronze=spark.sql("""select distinct
Product_Category,
Product
from lh_EndToEnd.bronze_sales where Modified_TS>'{}'""".format(Max_Date))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_bronze.show()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

Max_ID=spark.sql("select coalesce(max(Product_ID),0) from lh_EndToEnd.gold_product").first()[0]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

Max_ID

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_final=df_bronze.withColumn("Product_ID",monotonically_increasing_id()+Max_ID+1)
df_final.createOrReplaceTempView("ViewProduct")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC Select * from ViewProduct limit 3

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC merge into lh_EndToEnd.gold_product as gp 
# MAGIC using ViewProduct as vp  
# MAGIC on gp.Product=vp.Product and gp.Product_Category=vp.Product_Category
# MAGIC when MATCHED then 
# MAGIC update set
# MAGIC Modified_TS= current_timestamp()
# MAGIC 
# MAGIC when not matched then
# MAGIC INSERT
# MAGIC (
# MAGIC gp.Product_ID,
# MAGIC gp.Product_Category,
# MAGIC gp.Product,
# MAGIC gp.created_TS,
# MAGIC gp.Modified_TS
# MAGIC )
# MAGIC VALUES
# MAGIC (
# MAGIC vp.Product_ID,
# MAGIC vp.Product_Category,
# MAGIC vp.Product,
# MAGIC current_timestamp(),
# MAGIC current_timestamp()
# MAGIC 
# MAGIC )
# MAGIC 


# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC select * from gold_product

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }
