# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "8c247cbb-3313-46b8-a547-96af85cf523f",
# META       "default_lakehouse_name": "lh_EndToEnd",
# META       "default_lakehouse_workspace_id": "fa0e52bd-b9c0-4f5a-8da4-017a12a4a832"
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC create table if not EXISTS lh_EndToEnd.gold_fact_sale
# MAGIC (
# MAGIC Order_ID            string,
# MAGIC Price               float,
# MAGIC Quantity	        float,
# MAGIC Sales               float,
# MAGIC Discount            float,
# MAGIC Profit              float,
# MAGIC Shipping_Cost       float,
# MAGIC Order_Date          date,
# MAGIC Shipping_Date       date,
# MAGIC Product_ID          long,
# MAGIC OrderPriority_ID    long,
# MAGIC ShipMode_ID         long,
# MAGIC Customer_ID         string,
# MAGIC Order_Year          integer,
# MAGIC Order_Month         integer,
# MAGIC Created_TS          timestamp,
# MAGIC Modified_TS         timestamp	
# MAGIC )
# MAGIC using DELTA
# MAGIC PARTITIONED by (Order_Year,Order_Month)

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

Max_Date=spark.sql("select coalesce(max(Modified_TS),'1900-01-01') from lh_EndToEnd.Gold_Fact_Sale").first()[0]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

Max_Date

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_bronze= spark.sql("""select 
bronze_sales.Order_ID,
bronze_sales.Sales as Price,
bronze_sales.Quantity,
bronze_sales.Sales * bronze_sales.Quantity as Sales,
bronze_sales.Discount,
bronze_sales.Profit,
bronze_sales.Shipping_Cost,
bronze_sales.Order_Date,
bronze_sales.Shipping_Date,
gold_product.Product_ID,
gold_orderpriority.OrderPriority_ID,
gold_shipmode.ShipMode_ID,
bronze_sales.Customer_ID,
Year(Order_Date) as Order_Year,
Month(Order_Date) as Order_Month	
from lh_EndToEnd.bronze_sales 
inner join lh_EndToEnd.gold_product on bronze_sales.Product=gold_product.Product and 
                                             bronze_sales.Product_Category=gold_product.Product_Category
inner join lh_EndToEnd.gold_shipmode on bronze_sales.Ship_Mode= gold_shipmode.Ship_Mode
inner join lh_EndToEnd.gold_orderpriority on bronze_sales.Order_Priority=gold_orderpriority.Order_Priority
""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_bronze.show()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_bronze.createOrReplaceTempView("ViewFactSale")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC select * from ViewFactSale

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC merge into lh_EndToEnd.gold_fact_sale as gfs
# MAGIC using ViewFactSale as vfs 
# MAGIC on gfs.Order_Year=vfs.Order_Year and gfs.Order_Month=vfs.Order_Month and gfs.Order_ID=vfs.Order_ID
# MAGIC when matched then 
# MAGIC update SET
# MAGIC gfs.Sales =             vfs.Sales,
# MAGIC gfs.Price =             vfs.Price,
# MAGIC gfs.Quantity =          vfs.Quantity,
# MAGIC gfs.Discount =          vfs.Discount,
# MAGIC gfs.Profit =            vfs.Profit,
# MAGIC gfs.Shipping_Cost =     vfs.Shipping_Cost,
# MAGIC gfs.Order_Date =        vfs.Order_Date,
# MAGIC gfs.Shipping_Date =     vfs.Shipping_Date,
# MAGIC gfs.Product_ID =        vfs.Product_ID,
# MAGIC gfs.OrderPriority_ID =  vfs.OrderPriority_ID,
# MAGIC gfs.ShipMode_ID	=	    vfs.ShipMode_ID,
# MAGIC gfs.Customer_ID	=	    vfs.Customer_ID,
# MAGIC gfs.Modified_TS	=       current_timestamp()	
# MAGIC 
# MAGIC when not matched then
# MAGIC INSERT
# MAGIC (
# MAGIC gfs.Order_ID,
# MAGIC gfs.Sales,
# MAGIC gfs.Price,
# MAGIC gfs.Quantity,
# MAGIC gfs.Discount,
# MAGIC gfs.Profit,
# MAGIC gfs.Shipping_Cost,
# MAGIC gfs.Order_Date,
# MAGIC gfs.Shipping_Date,
# MAGIC gfs.Product_ID,
# MAGIC gfs.OrderPriority_ID,
# MAGIC gfs.ShipMode_ID,
# MAGIC gfs.Customer_ID,
# MAGIC gfs.Order_Year,
# MAGIC gfs.Order_Month,
# MAGIC gfs.Created_TS,
# MAGIC gfs.Modified_TS	
# MAGIC 
# MAGIC )
# MAGIC VALUES
# MAGIC (
# MAGIC vfs.Order_ID,
# MAGIC vfs.Sales,
# MAGIC vfs.Price,
# MAGIC vfs.Quantity,
# MAGIC vfs.Discount,
# MAGIC vfs.Profit,
# MAGIC vfs.Shipping_Cost,
# MAGIC vfs.Order_Date,
# MAGIC vfs.Shipping_Date,
# MAGIC vfs.Product_ID,
# MAGIC vfs.OrderPriority_ID,
# MAGIC vfs.ShipMode_ID,
# MAGIC vfs.Customer_ID,
# MAGIC vfs.Order_Year,
# MAGIC vfs.Order_Month,
# MAGIC current_timestamp(),
# MAGIC current_timestamp()
# MAGIC 
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC select * from gold_fact_sale limit 5

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }
