# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "8c247cbb-3313-46b8-a547-96af85cf523f",
# META       "default_lakehouse_name": "lh_EndToEnd",
# META       "default_lakehouse_workspace_id": "fa0e52bd-b9c0-4f5a-8da4-017a12a4a832",
# META       "known_lakehouses": [
# META         {
# META           "id": "8c247cbb-3313-46b8-a547-96af85cf523f"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from notebookutils import mssparkutils


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

mssparkutils.fs.mount("abfss://fa0e52bd-b9c0-4f5a-8da4-017a12a4a832@onelake.dfs.fabric.microsoft.com/8c247cbb-3313-46b8-a547-96af85cf523f/Files","/Files")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

mssparkutils.fs.getMountPath("/Files")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

check_files=mssparkutils.fs.ls(f"file://{mssparkutils.fs.getMountPath('/Files')}/Current/")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

check_files

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

if check_files:
    mssparkutils.notebook.run("nb_BronzeLayer")
    mssparkutils.notebook.run("nb_Gold_Customer")
    mssparkutils.notebook.run("nb_Gold_Date")
    mssparkutils.notebook.run("nb_Gold_Product")
    mssparkutils.notebook.run("nb_Gold_ShipMode")
    mssparkutils.notebook.run("nb_Gold_OrderPriority")
    #mssparkutils.notebook.run("nb_Gold_OrderReturn")
    mssparkutils.notebook.run("nb_Gold_Fact_Sale")
    mssparkutils.notebook.run("nb_Archive_Files")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
