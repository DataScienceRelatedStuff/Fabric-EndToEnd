# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "8c247cbb-3313-46b8-a547-96af85cf523f",
# META       "default_lakehouse_name": "lh_EndToEnd",
# META       "default_lakehouse_workspace_id": "fa0e52bd-b9c0-4f5a-8da4-017a12a4a832"
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC select * from lh_EndToEnd.Bronze_Sales

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC create table if not exists lh_EndToEnd.Gold_OrderReturn
# MAGIC (
# MAGIC     
# MAGIC Order_ID        string,
# MAGIC Return          string,
# MAGIC Order_Year      int,
# MAGIC Order_Month     int,
# MAGIC Created_TS      timestamp,
# MAGIC Modified_TS     timestamp
# MAGIC 
# MAGIC )
# MAGIC using delta 
# MAGIC partitioned by(Order_Year,Order_Month)

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC select "Modified_TS" from lh_EndToEnd.Gold_OrderReturn

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC select max("Modified_TS") from lh_EndToEnd.Gold_OrderReturn

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC select coalesce(max("Modified_TS"), "1900-01-01") from lh_EndToEnd.Gold_OrderReturn

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


Max_Date = spark.sql("select coalesce(max('Modified_TS'), '1900-01-01') from lh_EndToEnd.Gold_OrderReturn").first()[0]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

Max_Date

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC select
# MAGIC     Order_ID,
# MAGIC     Return,
# MAGIC     Order_Year,
# MAGIC     Order_Month,
# MAGIC     Created_TS,
# MAGIC     Modified_TS
# MAGIC from lh_EndToEnd.bronze_sales

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df=spark.sql("""select Order_ID,
Return,
Order_Year, 
Order_Month,
Created_TS,
Modified_TS 
from from lh_EndToEnd.bronze_sales where Modified_TS>'{}'""".format(Max_Date))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df=spark.sql("""select Order_ID,
Return,
Order_Year, 
Order_Month,
Created_TS,
Modified_TS 
from from lh_EndToEnd.bronze_sales where Return="Yes" and Modified_TS>'{}'""".format(Max_Date))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(df.head(5))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df.createOrReplaceTempView("ViewReturn")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC select * from ViewReturn

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC insert into lh_EndToEnd.Gold_OrderReturn
# MAGIC select * from ViewReturn

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC select * from lh_EndToEnd.Gold_OrderReturn limit 15

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }
